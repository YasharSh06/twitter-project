<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbName = "phpclass";

try {
    $db = new mysqli($servername, $username, $password,$dbName);
    $db->query("SET CHARACTER SET utf8;");
    $db->query("SET SESSION collation_connection = 'utf8_general_ci'");
}catch (Exception $e){
    echo $e->getMessage();
    die();
}